This is build of [QtMips](https://github.com/cvut/QtMips) v0.6.8 for macOS

In order to run this build,
please install [Qt](https://www.qt.io/) locally,
as it is not included in the build (it is linked dynamically).

Use [Homebrew](https://brew.sh/) to install Qt. Run:
```bash
brew install qt
```

builds directory https://github.com/pokusew/devbuntu/qtmips-builds
built by [pokusew](https://github.com/pokusew) on 3rd April 2019
